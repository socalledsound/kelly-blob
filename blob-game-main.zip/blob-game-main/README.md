# kelly game working a bit

-- could use some images facing the other way for moving left???
-- and then maybe give the slug the chance to collect some coin?

demo:https://socalledsound.github.io/kelly-slug-game/
